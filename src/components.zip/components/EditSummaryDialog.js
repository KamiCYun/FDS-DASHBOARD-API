import React, { useState } from "react";
import { Dialog, Pane, Text, TextInput } from "evergreen-ui";

const EditSummaryDialog = ({ isShown, onClose, semesterData, onSave }) => {
  const [tempData, setTempData] = useState({ ...semesterData });

  const handleChange = (key, value) => {
    setTempData((prev) => ({ ...prev, [key]: value }));
  };

  const handleSave = () => {
    // Adjust starting capital if current capital is changed
    if (tempData.currentCapital !== semesterData.startingCapital + semesterData.transactions.reduce((sum, txn) => sum + txn.amount, 0)) {
      const transactionTotal = tempData.transactions.reduce((sum, txn) => sum + txn.amount, 0);
      tempData.startingCapital = tempData.currentCapital - transactionTotal;
    }
    onSave(tempData);
    onClose();
  };

  return (
    <Dialog
      isShown={isShown}
      title="Edit Summary"
      onCloseComplete={onClose}
      onConfirm={handleSave}
      confirmLabel="Save"
    >
      <Pane display="flex" flexDirection="column" gap={16}>
        <Pane>
          <Text>Starting Capital:</Text>
          <TextInput
            placeholder="Edit Starting Capital"
            value={tempData.startingCapital}
            onChange={(e) => handleChange("startingCapital", parseFloat(e.target.value))}
          />
        </Pane>
        <Pane>
          <Text>Current Capital:</Text>
          <TextInput
            placeholder="Edit Current Capital"
            value={tempData.currentCapital}
            onChange={(e) => handleChange("currentCapital", parseFloat(e.target.value))}
          />
        </Pane>
        <Pane>
          <Text>Surplus:</Text>
          <TextInput
            placeholder="Surplus is calculated dynamically"
            value={tempData.currentCapital - tempData.startingCapital}
            disabled
          />
        </Pane>
        <Pane>
          <Text>Active House Size:</Text>
          <TextInput
            placeholder="Edit Active House Size"
            value={tempData.activeHouseSize}
            onChange={(e) => handleChange("activeHouseSize", parseInt(e.target.value))}
          />
        </Pane>
        <Pane>
          <Text>Insurance Cost:</Text>
          <TextInput
            placeholder="Edit Insurance Cost"
            value={tempData.insurance}
            onChange={(e) => handleChange("insurance", parseFloat(e.target.value))}
          />
        </Pane>
      </Pane>
    </Dialog>
  );
};

export default EditSummaryDialog;
