import React from "react";
import { Table, SelectMenu, Button } from "evergreen-ui";

const TransactionsTable = ({ transactions, categories, setSemesterData }) => {
  const handleCategoryChange = (index, newCategory) => {
    const updatedTransactions = [...transactions];
    updatedTransactions[index].category = newCategory;
    setSemesterData(updatedTransactions);
  };

  return (
    <Table marginTop={16}>
      <Table.Head>
        <Table.TextHeaderCell>Payer</Table.TextHeaderCell>
        <Table.TextHeaderCell>Time</Table.TextHeaderCell>
        <Table.TextHeaderCell>Message</Table.TextHeaderCell>
        <Table.TextHeaderCell>Amount</Table.TextHeaderCell>
        <Table.TextHeaderCell>Category</Table.TextHeaderCell>
      </Table.Head>
      <Table.Body>
        {transactions.map((txn, index) => (
          <Table.Row key={index}>
            <Table.TextCell>{txn.payer}</Table.TextCell>
            <Table.TextCell>{txn.time}</Table.TextCell>
            <Table.TextCell>{txn.message}</Table.TextCell>
            <Table.TextCell>${txn.amount}</Table.TextCell>
            <Table.TextCell>
              <SelectMenu
                title="Edit Category"
                options={categories.map((cat) => ({
                  label: cat,
                  value: cat,
                }))}
                selected={txn.category}
                onSelect={(item) => handleCategoryChange(index, item.value)}
              >
                <Button>{txn.category}</Button>
              </SelectMenu>
            </Table.TextCell>
          </Table.Row>
        ))}
      </Table.Body>
    </Table>
  );
};

export default TransactionsTable;
