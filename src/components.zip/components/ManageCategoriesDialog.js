import React, { useState } from "react";
import { Dialog, Pane, Text, TextInput, Button } from "evergreen-ui";

const ManageCategoriesDialog = ({ isShown, onClose, categories, onAddCategory, onDeleteCategory }) => {
  const [newCategory, setNewCategory] = useState("");

  return (
    <Dialog
      isShown={isShown}
      title="Manage Categories"
      onCloseComplete={onClose}
      confirmLabel="Done"
    >
      <Pane display="flex" flexDirection="column" gap={16}>
        <Pane>
          <Text>Add a New Category:</Text>
          <TextInput
            placeholder="Enter new category"
            value={newCategory}
            onChange={(e) => setNewCategory(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && newCategory.trim()) {
                onAddCategory(newCategory.trim());
                setNewCategory("");
              }
            }}
          />
          <Button
            appearance="primary"
            marginTop={8}
            onClick={() => {
              if (newCategory.trim()) {
                onAddCategory(newCategory.trim());
                setNewCategory("");
              }
            }}
          >
            Add
          </Button>
        </Pane>
        <Pane>
          <Text>Existing Categories:</Text>
          {categories.map((cat) => (
            <Pane
              key={cat}
              display="flex"
              alignItems="center"
              justifyContent="space-between"
              marginTop={8}
            >
              <Text>{cat}</Text>
              {cat !== "Uncategorized" && (
                <Button
                  appearance="minimal"
                  intent="danger"
                  onClick={() => onDeleteCategory(cat)}
                >
                  Delete
                </Button>
              )}
            </Pane>
          ))}
        </Pane>
      </Pane>
    </Dialog>
  );
};

export default ManageCategoriesDialog;
