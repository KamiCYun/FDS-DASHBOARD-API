import React from "react";
import { Pane, Text } from "evergreen-ui";
import LineGraph from "./LineGraph";
import PieChart from "./PieChart";

const Statistics = ({
  startingCapital,
  currentCapital,
  surplus,
  activeHouseSize,
  insurance,
  transactions,
}) => {
  const calculateCategoryBreakdown = () => {
    const breakdown = {};
    transactions.forEach((txn) => {
      breakdown[txn.category] = (breakdown[txn.category] || 0) + txn.amount;
    });
    return breakdown;
  };

  const calculateWeeklyBalances = () => {
    const weeklyBalances = [];
    let runningTotal = startingCapital;
    transactions.forEach((txn) => {
      runningTotal += txn.amount;
      weeklyBalances.push(runningTotal);
    });
    return weeklyBalances;
  };

  return (
    <Pane display="flex" alignItems="center" justifyContent="space-between" gap={16}>
      <Pane
        flex="1"
        display="flex"
        flexDirection="column"
        alignItems="flex-start"
        gap={16}
      >
        <Text size={600}>
          <strong>Starting Capital:</strong> ${startingCapital}
        </Text>
        <Text size={600}>
          <strong>Current Capital:</strong> ${currentCapital}
        </Text>
        <Text size={600}>
          <strong>Surplus/Negative:</strong> ${surplus}
        </Text>
        <Text size={600}>
          <strong>Active House Size:</strong> {activeHouseSize}
        </Text>
        <Text size={600}>
          <strong>Insurance Cost:</strong> ${insurance}
        </Text>
      </Pane>
      <Pane flex="2" height={300}>
        <LineGraph data={calculateWeeklyBalances()} />
      </Pane>
      <Pane flex="2" height={400}>
        <PieChart data={calculateCategoryBreakdown()} />
      </Pane>
    </Pane>
  );
};

export default Statistics;
